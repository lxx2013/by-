#ifndef _GLOBAL_HH_
#define _GLOBAL_HH_

extern char *infile_name;
extern char *outfile_name;
extern char *dumpfile_name;
extern char *codefile_name;
extern FILE *infp;
extern FILE *outfp;
extern FILE *dumpfp;
extern FILE *codefp;
#endif
