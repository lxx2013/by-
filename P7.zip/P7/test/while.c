#嵌套while
void main ()
{
	Output =1;
	int i=0;
	while(Output<100)
	{
		i = 0;
		while(i<10)
		{
			i = i+1;
			Output = Output +i;
			print();
		}
	}


}
