const int i=1+2+3+4+5;
const int a[5] = {1,2,3,4,666};
void main(){
	Output = a[4];
	print();
}
