#嵌套while
void main ()
{
	Output =1;
	int i=0;
	while(1<2)
	{
		print();
		Output = Output +Output;
		if(Output > 20)
			break;
		else 
			continue;
		Output = Output +1;
	}

}
