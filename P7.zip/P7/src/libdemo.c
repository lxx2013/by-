#include <stdio.h>

// Declare a global variable
int Output = 233;
int Input = 233;
void print() {
    printf("%d\n", Output);
}
void scan(){
	scanf("%d",&Input);
}
